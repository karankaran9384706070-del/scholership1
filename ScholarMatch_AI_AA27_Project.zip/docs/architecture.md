# AA-27 Architecture

Search Agent → Match Agent → Tracking Agent → Draft Agent → Human Approval → Submission Agent

## Agent responsibilities
- Search: retrieve scholarship/internship records.
- Match: compare structured requirements against the student profile.
- Tracking: monitor deadlines and missing documents.
- Draft: prepare application text.
- Human Approval: mandatory checkpoint before submission.
- Submission: safe simulated submission for the MVP.

## Metrics
Precision = TP / (TP + FP)
Recall = TP / (TP + FN)
F1 = 2PR / (P + R)
Submission success rate = successful submissions / approved attempts
