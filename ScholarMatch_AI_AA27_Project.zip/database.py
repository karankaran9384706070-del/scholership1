import sqlite3
from pathlib import Path

DB = Path("scholarmatch.db")

def conn():
    return sqlite3.connect(DB)

def init_db():
    c = conn()
    cur = c.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS opportunities (
        id INTEGER PRIMARY KEY, title TEXT, type TEXT, deadline TEXT,
        course TEXT, min_cgpa REAL, max_income INTEGER, location TEXT,
        year INTEGER, skills TEXT, documents TEXT, ground_truth_eligible INTEGER
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT, opportunity_id INTEGER,
        opportunity_title TEXT, student_name TEXT, draft TEXT, status TEXT
    )""")
    if cur.execute("SELECT COUNT(*) FROM opportunities").fetchone()[0] == 0:
        data = [
            (1,"AI Future Scholars Grant","Scholarship","2026-10-18","AI & Data Science",7.5,500000,"Tamil Nadu",2,"Python,Machine Learning","Bonafide Certificate,Income Certificate",1),
            (2,"Women in Technology Internship","Internship","2026-10-25","Computer Science",7.0,99999999,"India",2,"Python,SQL","Resume,Bonafide Certificate",1),
            (3,"Advanced Computing Excellence Award","Scholarship","2026-11-05","Computer Science",9.0,300000,"India",2,"Algorithms","Income Certificate,Mark Sheet",0),
            (4,"Rural Student Support Scholarship","Scholarship","2026-10-30","Any",6.5,250000,"Tamil Nadu",1,"Any","Income Certificate,Bonafide Certificate",1)
        ]
        cur.executemany("INSERT INTO opportunities VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", data)
    c.commit()
    c.close()

def get_opportunities():
    c = conn()
    c.row_factory = sqlite3.Row
    rows = [dict(x) for x in c.execute("SELECT * FROM opportunities ORDER BY deadline").fetchall()]
    c.close()
    return rows

def save_application(opp_id, student, draft):
    c = conn()
    title = c.execute("SELECT title FROM opportunities WHERE id=?", (opp_id,)).fetchone()[0]
    c.execute("INSERT INTO applications(opportunity_id,opportunity_title,student_name,draft,status) VALUES(?,?,?,?,?)",
              (opp_id,title,student,draft,"Pending Approval"))
    c.commit()
    c.close()

def get_applications():
    c = conn()
    c.row_factory = sqlite3.Row
    rows = [dict(x) for x in c.execute("SELECT * FROM applications ORDER BY id DESC").fetchall()]
    c.close()
    return rows

def update_application(app_id, status):
    c = conn()
    c.execute("UPDATE applications SET status=? WHERE id=?", (status, app_id))
    c.commit()
    c.close()
