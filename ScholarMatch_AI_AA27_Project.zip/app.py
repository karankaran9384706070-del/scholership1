import streamlit as st
import pandas as pd
from database import init_db, get_opportunities, save_application, get_applications, update_application
from agents.match_agent import calculate_match
from agents.draft_agent import create_draft

st.set_page_config(page_title="ScholarMatch AI", page_icon="🎓", layout="wide")
init_db()

st.title("🎓 ScholarMatch AI")
st.caption("AA-27 — Autonomous Scholarship–Student Matching Agent")

if "profile" not in st.session_state:
    st.session_state.profile = {
        "name": "", "course": "AI & Data Science", "year": 2,
        "cgpa": 8.0, "income": 250000, "location": "Tamil Nadu",
        "skills": "Python, SQL, Machine Learning",
        "documents": "Bonafide Certificate, Aadhaar"
    }

tabs = st.tabs(["👤 Profile", "🔎 Match", "📝 Applications", "📊 Evaluation"])

with tabs[0]:
    p = st.session_state.profile
    c1, c2 = st.columns(2)
    with c1:
        p["name"] = st.text_input("Student name", p["name"])
        p["course"] = st.text_input("Course", p["course"])
        p["year"] = st.number_input("Year", 1, 5, p["year"])
        p["cgpa"] = st.number_input("CGPA", 0.0, 10.0, float(p["cgpa"]), 0.1)
    with c2:
        p["income"] = st.number_input("Annual family income (₹)", 0, 10000000, int(p["income"]), 1000)
        p["location"] = st.text_input("Location", p["location"])
        p["skills"] = st.text_input("Skills", p["skills"])
        p["documents"] = st.text_input("Available documents", p["documents"])
    st.success("Profile saved for this session.")

with tabs[1]:
    st.subheader("Search and Match Opportunities")
    opportunities = get_opportunities()
    rows = []
    for opp in opportunities:
        result = calculate_match(st.session_state.profile, opp)
        rows.append({
            "ID": opp["id"], "Opportunity": opp["title"], "Type": opp["type"],
            "Deadline": opp["deadline"], "Match": f'{result["score"]:.0f}%',
            "Status": "Eligible" if result["eligible"] else "Not eligible"
        })
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    selected = st.selectbox("Select an opportunity", [o["title"] for o in opportunities])
    opp = next(o for o in opportunities if o["title"] == selected)
    result = calculate_match(st.session_state.profile, opp)

    st.metric("Match score", f'{result["score"]:.0f}%')
    c1, c2 = st.columns(2)
    with c1:
        st.write("### Eligibility")
        for item in result["reasons"]:
            st.write(("✅ " if item["pass"] else "⚠️ ") + item["text"])
    with c2:
        st.write("### Required documents")
        for doc in opp["documents"].split(","):
            doc = doc.strip()
            available = any(doc.lower() in x.lower() for x in st.session_state.profile["documents"].split(","))
            st.write(("✅ " if available else "📄 ") + doc)

    if st.button("Create application draft", disabled=not result["eligible"]):
        draft = create_draft(st.session_state.profile, opp)
        save_application(opp["id"], st.session_state.profile["name"] or "Demo Student", draft)
        st.success("Draft created. Human approval is required before submission.")
        st.text_area("Draft", draft, height=240)

with tabs[2]:
    st.subheader("Human Approval Checkpoint")
    apps = get_applications()
    if not apps:
        st.info("No applications yet.")
    for app in apps:
        with st.expander(f'{app["opportunity_title"]} — {app["status"]}'):
            st.text(app["draft"])
            if app["status"] == "Pending Approval":
                if st.button("✅ Approve & Submit (Simulation)", key=f'approve_{app["id"]}'):
                    update_application(app["id"], "Submitted")
                    st.success("Application submitted successfully in simulation mode.")
                if st.button("❌ Reject", key=f'reject_{app["id"]}'):
                    update_application(app["id"], "Rejected")
                    st.warning("Application rejected.")

with tabs[3]:
    st.subheader("Evaluation Metrics")
    opportunities = get_opportunities()
    if opportunities:
        correct = sum(
            calculate_match(st.session_state.profile, o)["eligible"] == bool(o["ground_truth_eligible"])
            for o in opportunities
        )
        st.metric("Demo-set eligibility classification accuracy", f"{correct/len(opportunities)*100:.1f}%")
    apps = get_applications()
    attempted = sum(a["status"] in ("Submitted", "Rejected", "Pending Approval") for a in apps)
    submitted = sum(a["status"] == "Submitted" for a in apps)
    st.metric("Simulated submission success rate", f"{submitted/attempted*100:.1f}%" if attempted else "0.0%")
    st.caption("For the final report, use a larger labeled test set and calculate precision, recall and F1.")
