# ScholarMatch AI — AA-27

Autonomous Scholarship–Student Matching Agent.

## Features
- Student profile management
- Scholarship/internship opportunity database
- Search → Match → Track → Draft → Human Approval → Submit workflow
- Structured eligibility scoring
- Application draft generation
- Deadline/document tracking
- Simulated submission for safe demonstration
- Evaluation metrics

## Run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

The submission step is intentionally simulated. The human approval checkpoint must remain before any real submission integration.
