def create_draft(profile, opportunity):
    name = profile["name"] or "Student"
    return f"""APPLICATION DRAFT

Applicant: {name}
Opportunity: {opportunity["title"]}

Dear Selection Committee,

I am a {profile["year"]} year student pursuing {profile["course"]}. My current CGPA is {profile["cgpa"]}. I am interested in this opportunity because it aligns with my academic interests and skills in {profile["skills"]}.

I would be grateful for the opportunity to learn, contribute, and develop my technical skills through this program. I will provide all required documents before final submission.

Thank you for considering my application.

Sincerely,
{name}
"""
