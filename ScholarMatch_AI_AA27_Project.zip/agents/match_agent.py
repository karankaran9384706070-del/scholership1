def calculate_match(profile, opp):
    checks = []
    course_ok = opp["course"].lower() == "any" or opp["course"].lower() in profile["course"].lower()
    checks.append((25, course_ok, f'Course: {profile["course"]}'))
    cgpa_ok = float(profile["cgpa"]) >= float(opp["min_cgpa"])
    checks.append((25, cgpa_ok, f'CGPA: {profile["cgpa"]} / minimum {opp["min_cgpa"]}'))
    income_ok = int(profile["income"]) <= int(opp["max_income"])
    checks.append((20, income_ok, f'Income: ₹{profile["income"]:,} / maximum ₹{opp["max_income"]:,}'))
    loc_ok = opp["location"].lower() in ("india","any") or opp["location"].lower() in profile["location"].lower()
    checks.append((15, loc_ok, f'Location: {profile["location"]}'))
    year_ok = int(profile["year"]) >= int(opp["year"])
    checks.append((15, year_ok, f'Year: {profile["year"]} / minimum {opp["year"]}'))
    score = sum(weight for weight, ok, _ in checks if ok)
    return {
        "score": score,
        "eligible": all(ok for _, ok, _ in checks),
        "reasons": [{"pass": ok, "text": text} for _, ok, text in checks]
    }
